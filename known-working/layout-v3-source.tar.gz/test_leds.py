"""Linked LED-image checks and host execution of the real RK61 LED driver."""

import json
import re
import subprocess
import tempfile
import unittest
from pathlib import Path

import test_prototype as prototype

ROOT = Path(__file__).resolve().parent
BOARD = ROOT / "smk/src/keyboards/royalkludge-rk61"
STEM = "royalkludge-rk61_led-test_smk"


class LedImageChecks(prototype.PrototypeChecks):
    @classmethod
    def setUpClass(cls):
        cls.image = prototype.load_hex(prototype.BUILD / f"{STEM}.hex")
        cls.mapping = json.loads((ROOT / "matrix.json").read_text())
        cls.linkmap = (prototype.BUILD / f"{STEM}.map").read_text()

    def test_interrupt_check_passed(self):
        self.assertTrue((prototype.BUILD / "royalkludge-rk61_led-test_smk.interrupts-ok").is_file())

    def test_led_shortcuts(self):
        toggle, channel = self.key(self.FN_LAYER, 1, 1), self.key(self.FN_LAYER, 1, 3)
        self.assertGreaterEqual(toggle, 0x7E00)
        self.assertEqual(channel, toggle + 1)


class LedDriverChecks(unittest.TestCase):
    def test_real_driver_and_layer_policy_with_mock_registers(self):
        header = (ROOT / "smk/src/sino51lib/sh68f90/sh68f90.h").read_text()
        names = re.findall(r"^SFRX?\((\w+),", header, re.M)
        declarations = [f"#define {name} mock_regs[{i}]" for i, name in enumerate(names)]
        mock = "\n".join([
            "#pragma once", "#include <stdint.h>", "#include <stdbool.h>",
            "extern volatile uint8_t mock_regs[512];", *declarations,
            "#define MATRIX_COLS 14", "#define DRVCON_UNLOCK_P1 5",
            "#define DRVCON_UNLOCK_P2 0x45", "#define DRVCON_UNLOCK_P3 0x85",
            "#define DRVCON_LOCK 0", "#define GPIO_DRIVE_25MA 0",
            "enum { RK61_LED_TOGGLE = 0x7e00, RK61_LED_CHANNEL,",
            "       RK61_LED_BRIGHTNESS_DOWN = 0x7e09, RK61_LED_BRIGHTNESS_UP };",
            "typedef struct { uint8_t unused; } keyboard_state_t;",
            "uint8_t get_action_layer(void);",
            "void user_matrix_cols_deselect_all(void);",
            "void user_matrix_col_select(uint8_t col);",
        ]) + "\n"
        harness = r'''
#include <assert.h>
#include <stdio.h>
#include "mock.h"
volatile uint8_t mock_regs[512];
static int selected = -1;
static uint8_t held_layer;
uint8_t get_action_layer(void) { return held_layer; }
void user_matrix_cols_deselect_all(void) { selected = -1; }
void user_matrix_col_select(uint8_t col) {
    assert(selected == -1 && col < MATRIX_COLS);
    selected = col;
}
#include "POLICY_PATH"
#include "DRIVER_PATH"
static unsigned duty(uint8_t hi, uint8_t lo) { return ((unsigned)hi << 8) | lo; }
static void check_duties(unsigned green, unsigned red, unsigned blue) {
    const unsigned pulses[] = {green, red, blue};
#define CHECK(channel, off, group, populated) \
    assert(duty(channel##DUTY1H, channel##DUTY1L) == (off)); \
    assert(duty(channel##DUTY2H, channel##DUTY2L) == (off) + ((populated) ? pulses[group] : 0)); \
    assert(duty(channel##DUTY2H, channel##DUTY2L) - (off) <= 64);
    LED_CHANNELS(CHECK)
#undef CHECK
}
static void check_parked(void) {
    assert(selected == -1);
#define CHECK_PARK(channel, off, group, populated) assert(channel##CON == 0x12);
    LED_CHANNELS(CHECK_PARK)
#undef CHECK_PARK
}
static void render(unsigned green, unsigned red, unsigned blue) {
    indicators_update_step(0, 0);
    assert(selected >= 0 && selected < 14);
    assert(PWM00CON == 0x8a && PWM10CON == 0x8a && PWM20CON == 0x8a);
    check_duties(green, red, blue);
}
static void press(uint16_t code) {
    assert(!layout_process_record(code, true));
    assert(!layout_process_record(code, false));
}
int main(void) {
    indicators_init();
    check_duties(0, 0, 0);
    held_layer = RK61_LAYER_1;
    indicators_update_step(0, 0); // layers cannot light LEDs before start
    check_parked();
    assert(PWM0PERDH == 5 && PWM0PERDL == 0x37);
    assert(PWM1PERDH == 5 && PWM1PERDL == 0x37);
    assert(PWM2PERDH == 5 && PWM2PERDL == 0x37);
    held_layer = RK61_BASE;
    indicators_init();
    indicators_start();
    for (int col = 0; col < 14; ++col) {
        assert(indicators_update_step(0, 0) == (col == 13));
        assert(selected == col);
        check_duties(64, 64, 64);
    }
    indicators_pwm_disable();
    check_parked();
    indicators_pwm_enable();
    check_parked(); // scan completion never restores a stale LED sink

    // Releases alone must not change any setting.
    assert(!layout_process_record(RK61_LED_TOGGLE, false));
    assert(!layout_process_record(RK61_LED_CHANNEL, false));
    assert(!layout_process_record(RK61_LED_BRIGHTNESS_DOWN, false));
    assert(!layout_process_record(RK61_LED_BRIGHTNESS_UP, false));
    render(64, 64, 64);

    // Independently specified expected G/R/B values, at full 64-count brightness.
    static const uint8_t colours[][3] = {
        {64,64,64}, {64,0,0}, {0,64,0}, {0,0,64}, {64,64,0},
        {64,0,64}, {0,64,64}, {16,64,0}, {0,32,64}
    };
    assert(RK61_COLOUR_COUNT == sizeof(colours) / sizeof(colours[0]));
    for (unsigned colour = 0; colour < 9; ++colour) {
        for (unsigned step = 4; step > 0; --step) {
            unsigned b = step * 16;
            held_layer = RK61_BASE;
            render(colours[colour][0] * step / 4, colours[colour][1] * step / 4,
                   colours[colour][2] * step / 4);
            held_layer = RK61_LAYER_1; render(b, 0, 0);
            held_layer = RK61_LAYER_2; render(0, 0, b);
            held_layer = RK61_LAYER_3; render(0, b, b);
            held_layer = RK61_FN; render(b, b, 0);
            held_layer = RK61_BASE;
            assert(!layout_process_record(RK61_LED_BRIGHTNESS_DOWN, false));
            press(RK61_LED_BRIGHTNESS_DOWN);
        }
        // Clamp at the minimum; it is a dim level, not a second off switch.
        for (int i = 0; i < 20; ++i) press(RK61_LED_BRIGHTNESS_DOWN);
        render(colours[colour][0] / 4, colours[colour][1] / 4, colours[colour][2] / 4);
        // Clamp at the original 64-count maximum; no overdrive or wraparound.
        for (int i = 0; i < 20; ++i) press(RK61_LED_BRIGHTNESS_UP);
        render(colours[colour][0], colours[colour][1], colours[colour][2]);
        press(RK61_LED_CHANNEL);
    }
    render(64, 64, 64); // full palette wraps back to white

    // Changing the base colour under Fn does not change Fn's yellow override.
    held_layer = RK61_FN;
    press(RK61_LED_CHANNEL); render(64, 64, 0);
    press(RK61_LED_BRIGHTNESS_DOWN); render(48, 48, 0);
    held_layer = RK61_BASE; render(48, 0, 0); // restore selected green, at 48

    press(RK61_LED_TOGGLE);
    for (unsigned layer = 0; layer <= 4; ++layer) {
        held_layer = layer;
        indicators_update_step(0, 0);
        check_parked(); // OFF wins over every layer, including Fn
    }
    press(RK61_LED_CHANNEL); // green -> red while off
    press(RK61_LED_BRIGHTNESS_DOWN); // 48 -> 32 while off
    indicators_update_step(0, 0); check_parked();
    held_layer = RK61_LAYER_3;
    press(RK61_LED_TOGGLE); render(0, 32, 32);
    held_layer = RK61_BASE; render(0, 32, 0); // red selection was retained
    held_layer = 250; render(0, 32, 0); // unknown layer: use normal colour

    indicators_init(); // boot defaults are white/full dim brightness, initially off
    indicators_update_step(0, 0); check_parked();
    held_layer = RK61_BASE;
    indicators_start(); render(64, 64, 64);
    assert(layout_process_record(4, true));
    puts("PASS: 9 colours x 4 brightness levels, layer overrides/off, caps, blanking, 14-column sweep");
}
'''.replace("DRIVER_PATH", str(BOARD / "layouts/led-test/indicators.c")).replace(
            "POLICY_PATH", str(BOARD / "layouts/rf-test/lighting.c"))
        with tempfile.TemporaryDirectory(prefix="rk61-led-unit-") as temp:
            directory = Path(temp)
            (directory / "mock.h").write_text(mock)
            for name in ["kbdef.h", "indicators.h", "user_layout.h", "user_matrix.h", "layout.h"]:
                (directory / name).write_text('#include "mock.h"\n')
            (directory / "pwm_hw.h").write_text("#pragma once\n")
            (directory / "test.c").write_text(harness)
            subprocess.run(["cc", "-std=c11", "-Wall", "-Wextra", "-Werror", "-Wno-unused-value",
                            "-I", temp, "-I", str(BOARD), "-I", str(ROOT / "smk/src/sino51lib"),
                            str(directory / "test.c"), "-o", str(directory / "test")], check=True)
            subprocess.run([str(directory / "test")], check=True)


if __name__ == "__main__":
    unittest.main(verbosity=2)
