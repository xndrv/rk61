# RK61 layer maps — layout v3

**Development candidate; not flashed or hardware-confirmed.** These maps adapt
`corne.vil` by keeping its bindings on the same letter/punctuation keys. The
preserved all-mode baseline and layout-v1/v2 candidates are unchanged.
See [README.md](README.md) for recovery and flashing precautions.

## Layer keys

The bottom row, by physical position, is now:

```text
[Ctrl][Alt][ L1 ][                Space                 ][ L2 ][Win][ L3 ][Fn]
```

| Original position | New function |
|---|---|
| Left Ctrl | Left Ctrl |
| Windows | Left Alt |
| Left Alt | Hold Layer 1: numbers/navigation |
| Space | Space |
| Right Alt | Hold Layer 2: symbols |
| Menu / down-arrow legend | Windows (Left GUI) |
| Right Ctrl / right-arrow legend | Hold Layer 3: media/utilities |
| Fn | Hold the separate service layer |

Hold to activate, release to leave. Priority is **Fn > L3 > L2 > L1**.
Holding L1+L2 selects L2, **not** L3; L3 has its own dedicated key.
Releasing a higher layer restores any lower layer still held.

`--` means **disabled**, not transparent. User layers explicitly keep Backspace,
Enter, Space, both Shifts, Left Ctrl, Left Alt, Windows, and all four layer keys.
Tab remains Tab on L1/L2 but toggles lighting on L3. There is no Right Ctrl or
Right Alt modifier on the current base map.

## Base — normal typing

All non-bottom-row keys keep their existing US assignments.

```text
[Esc ][ 1 ][ 2 ][ 3 ][ 4 ][ 5 ][ 6 ][ 7 ][ 8 ][ 9 ][ 0 ][ - ][ = ][Backspace]
[ Tab ][ Q ][ W ][ E ][ R ][ T ][ Y ][ U ][ I ][ O ][ P ][ [ ][ ] ][    \    ]
[ Caps ][ A ][ S ][ D ][ F ][ G ][ H ][ J ][ K ][ L ][ ; ][ ' ][   Enter    ]
[ Shift  ][ Z ][ X ][ C ][ V ][ B ][ N ][ M ][ , ][ . ][ / ][ Right Shift  ]
[Ctrl][Alt][ L1 ][                Space                 ][ L2 ][Win][ L3 ][Fn]
```

## Layer 1 — numbers/navigation

```text
[ -- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][Backspace]
[ Tab ][ 1 ][ 2 ][ 3 ][ 4 ][ 5 ][ 6 ][ 7 ][ 8 ][ 9 ][ 0 ][-- ][-- ][    --   ]
[  --  ][-- ][-- ][-- ][-- ][-- ][Left][Down][Up][Right][-- ][-- ][   Enter    ]
[ Shift  ][F1 ][F2 ][F3 ][F4 ][F5 ][F6 ][F7 ][F8 ][F9 ][F10][ Right Shift   ]
[Ctrl][Alt][ L1 ][                Space                 ][ L2 ][Win][ L3 ][Fn]
```

- Q through P send 1 through 0.
- H/J/K/L send Left/Down/Up/Right.
- Z/X/C/V/B/N/M/comma/dot/slash send F1 through F10.
- Modifiers remain available for Ctrl+arrow and Shift+arrow selection.
- F11/F12 remain on Fn+- / Fn+=; Right Shift is not repurposed as F11.

## Layer 2 — symbols

Characters shown assume a **US host keyboard layout**; firmware sends HID keys
with Shift where needed, rather than literal text.

```text
[ -- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][Backspace]
[ Tab ][ ! ][ @ ][ # ][ $ ][ % ][ ^ ][ & ][ * ][ ( ][ ) ][-- ][-- ][    --   ]
[  --  ][-- ][-- ][-- ][-- ][-- ][ - ][ = ][ [ ][ ] ][ \ ][ ` ][   Enter    ]
[ Shift  ][-- ][-- ][-- ][-- ][-- ][ _ ][ + ][ { ][ } ][ | ][ Right Shift  ]
[Ctrl][Alt][ L1 ][                Space                 ][ L2 ][Win][ L3 ][Fn]
```

This follows your Corne's Q–P, H–quote, and N–slash positions. Right Shift stays
Shift; **Fn+Shift+Esc** provides tilde (`~`). Shifted symbols retain their own
synthetic Shift until released, without removing a separately held physical
Shift or the Shift needed by another held symbol.

## Layer 3 — media/utilities

```text
[ -- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][-- ][Backspace]
[ LED ][Vol-][Vol+][Colour][-- ][-- ][PrtSc][-- ][-- ][-- ][-- ][-- ][-- ][ -- ]
[  --  ][-- ][-- ][-- ][Bright+][-- ][Prev][Next][Play][-- ][-- ][-- ][ Enter ]
[ Shift  ][-- ][-- ][-- ][Bright-][-- ][-- ][-- ][-- ][-- ][-- ][Right Shift]
[Ctrl][Alt][ L1 ][                Space                 ][ L2 ][Win][ L3 ][Fn]
```

| Chord | Action |
|---|---|
| L3+Q / W | Volume down / up |
| L3+H / J / K | Previous track / next track / play-pause |
| L3+Y | Print Screen |
| L3+F / V | **Display** brightness up / down, where supported by the host |
| L3+Tab | Existing keyboard LEDs on/off |
| L3+E | Cycle the nine-colour normal/base palette (visible after releasing L3) |

Media, screenshot, and display-brightness positions match `corne.vil`. Print
Screen sends the ordinary keyboard usage; the OS decides how screenshots work.
Display brightness does not change keyboard LED brightness.

The Corne's RGB toggle is adapted to L3+Tab. Its hue/saturation/effect controls
are not copied; L3+E cycles the normal palette instead. Keyboard brightness now
has dedicated Fn+[ / Fn+] controls, separate from L3+F/V display brightness. The Corne's bootloader and encoder controls are
not copied. No new lighting effects or higher LED drive are introduced.

## Fn — existing service shortcuts retained

`.` means **explicitly use the base assignment**, unlike `--`.

```text
[Grave][F1 ][F2 ][F3 ][F4 ][F5 ][F6 ][F7 ][F8 ][F9 ][F10][F11][F12][ Delete ]
[  .  ][LED][Up ][Colour][2.4][USB][Info][ . ][ . ][ . ][Pair][LED-][LED+][ . ]
[   .  ][Left][Down][Right][ . ][ . ][ . ][ . ][ . ][ . ][ . ][ . ][ Enter ]
[ Shift  ][ . ][ . ][ . ][ . ][BT1][BT2][BT3][ . ][Colour][ . ][Right Shift]
[Ctrl][Alt][ L1 ][                Space                 ][ L2 ][Win][ L3 ][Fn]
```

- 2.4 = original dongle; USB = wired output; Info = radio status on USB console.
- BT1/BT2/BT3 remain on **B/N/M** for now; Q/W/E slot controls are a later step.
- Pair = explicit pairing for the selected Bluetooth slot, ignored in USB/dongle mode.
- Fn's internal index is now **4**, keeping the actual user Layer 3 separate.
- Media/system releases are requested on the old route before changing transport
  or starting pairing. This is not a general reconnection/delivery guarantee;
  bounded radio retries and lost wireless releases remain a known limitation.
- No per-key mode indication or battery warning is added yet.

## Layer colours and keyboard lighting

| State | Keyboard colour (while LEDs are enabled) |
|---|---|
| Base | Your selected normal colour; white at boot |
| Hold L1 | Green |
| Hold L2 | Blue |
| Hold L3 | Magenta |
| Hold Fn | Yellow |

Lighting follows the same layer priority as typing: **Fn > L3 > L2 > L1**.
Release a higher layer to see the remaining held layer, or your selected base
colour. **Off stays completely dark**, even while holding layers.

| Chord | Lighting control |
|---|---|
| Fn+Q or L3+Tab | LEDs on/off; retains colour and brightness |
| Fn+[ | Dim keyboard LEDs one step |
| Fn+] | Brighten keyboard LEDs one step |
| Fn+. | Cycle the normal/base colour |
| Fn+E or L3+E | Colour-cycle aliases |

Cycle: **white → green → red → blue → yellow → cyan → magenta → orange →
violet → white**. While Fn/L3 is held its fixed layer colour remains visible;
release it to see your newly selected base colour. Brightness applies to both
base and layer colours immediately.

Four brightness steps use **16 / 32 / 48 / 64 PWM counts per full-strength
channel**, starting at 64. Fn+] at the maximum and Fn+[ at the minimum do
nothing; the minimum is dim, not off. Use the toggle to turn LEDs off. Mixed
colours use equal or fractional channel pulses; orange/violet are uncalibrated
recipes whose actual appearance must be checked on hardware.

No channel exceeds the baseline's existing 64-count pulse. GPIO drive, PWM
period, LED/scan scheduling and scan blanking remain unchanged. This provides
dimming, **not a brighter maximum** or an electrical-safety certification.
Colour, brightness, and the on/off choice reset at power-on; no settings writes
were added. Per-key connection/battery indicators remain future work.

Implementation: `lighting.h` defines the palette and bounds;
`layouts/rf-test/lighting.c` maps the atomic active-layer snapshot to a colour;
the reused `layouts/led-test/indicators.c` driver handles PWM and key controls.
The earlier wired/LED diagnostic layouts use the same palette/brightness driver
but have no per-layer colour override.

## Editing a binding

Edit **`smk/src/keyboards/royalkludge-rk61/layouts/rf-test/layout.c`**.
Each `RK61_LAYOUT_ANSI(...)` block follows physical rows, left to right:
**14 / 14 / 13 / 12 / 8** keys. The helper hides the electrical holes.

| Entry | Meaning |
|---|---|
| `OFF` | Disabled key (`KC_NO`); default for unassigned user-layer keys |
| `KC_A`, `KC_LEFT`, etc. | Ordinary key or modifier |
| `LSFT(KC_1)` | Shift+1, producing `!` with a US host layout |
| `PASS` | Explicitly reuse the base assignment; not the user-layer default |
| `L1`, `L2`, `L3`, `FN` | Hold the corresponding layer |

Keep the four layer-control positions as shown: the action handler always
recognizes base-layer hold keys. A key already held during a layer change keeps
its original action until release. An `OFF` key pressed under a layer stays
silent even if the layer is released first; entering a layer does not cancel
already-held keys.

These are compile-time maps: edit, build/test, then flash a distinct candidate.
There is no live remapping app or support for Corne/QMK tap-hold/macros/combos.

## Validation and candidate

```sh
cd ~/rk61-recovery
export PATH="$PWD/venv/bin:$PWD/toolchain/usr/bin:$PWD/toolchain/bin:$PATH"
meson compile -C smk/build-rf-debug royalkludge-rk61-rf-test_default_smk.hex
python3 test_bluetooth.py
python3 test_keymap.py
python3 -m unittest test_leds.LedDriverChecks -v
```

Layout v3 passed the SDCC build and interrupt checker, 20 Bluetooth-suite checks,
and the host harness executing the real keymap, matrix handler, report encoder
and layer-colour policy in **both 6KRO and NKRO modes**. Tests cover disabled keys, layer priority,
shifted-symbol overlap, independently held modifiers, duplicate usages across
layers, media usage values/releases, Print Screen, and preserved Fn behavior.
The LED register-mock harness also checks all nine colours at all four brightness
levels, held-layer overrides, off precedence, release-only events, palette wrap,
brightness clamping, unchanged PWM/off points, blanking, and column sweep.
The broader regression run passed **45 tests**, including rebuilt earlier RK61
prototype and LED targets.

These checks do **not** prove GPIO timing, actual LED current/temperature/colour
appearance, real USB/radio delivery, OS support, or over-air Bluetooth behavior. Hardware validation remains outstanding.

**Candidate:** `candidate-layout-v3.bin`, 61,440 bytes; matching
`candidate-layout-v3.hex`. Binary SHA-256:
`959fc33e791bbecdc194945d9d39d92d64611a653a9dc8142a04d547d5e74b32`.
Highest linked address: `0x4F38`, below the `0xEC00` settings boundary. ISP stays
enabled. The preserved baseline and all layout-v1/v2 artifacts were
checksum-verified unchanged. Never overwrite them with a new experiment.

To test, keep another usable keyboard and a USB cable available. Run this
**yourself in your terminal**, not through the agent:

```sh
sudo ~/rk61-recovery/toolchain/bin/sinowisp write \
  --platform sh68f90 --vendor_id 0x258a --product_id 0x00e1 \
  --format bin --reboot true \
  ~/rk61-recovery/candidate-layout-v3.bin
```

Do not use generated flash targets, a preset, or a full stock dump. The README
has the explicit preserved-baseline restore command if USB ISP remains accessible.
No flash was performed by the agent.

## Hardware checklist — results not yet recorded

1. Confirm the bottom row, especially Right Ctrl now holding L3 rather than Ctrl.
2. Test L1 numbers/F-keys/HJKL arrows, including Ctrl+Shift+arrow selection.
3. Test L2 symbols, two symbols held together, and a separately held Shift.
   Release the layer before the symbol too; check for stuck keys/modifiers.
4. Test an unmapped key (e.g. L1+A) produces nothing, even when releasing L1 first.
5. Test all media keys, L3+Y, and display brightness on your OS. Brightness or
   screenshot behavior may differ by host; record observed results, not assumptions.
6. Test L3+Tab/E and all existing Fn controls. Check USB, the original dongle,
   and an already-paired Bluetooth host, especially media press/release on each.
   Layout testing alone should not require re-pairing.
7. Test overlapping layer holds restore both the correct bindings and colour:
   L1 green, L2 blue, L3 magenta, Fn yellow, then normal colour on release.
8. Cycle all nine colours with Fn+.; release Fn to see the selection. Test
   Fn+[ / Fn+] at every brightness level and at both limits. Confirm Fn+E/L3+E
   aliases, on/off precedence under every layer, and that typing/scanning remains
   reliable while lighting is active. Watch for flicker, unexpected heat or colour
   differences; stop and power off if anything behaves abnormally.
9. Release media keys before switching hosts for normal use; separately verify
   mode-switch releases with another keyboard available to stop a stuck command.
