#pragma once

#include <stdint.h>

enum rk61_led_colour {
    RK61_COLOUR_WHITE,
    RK61_COLOUR_GREEN,
    RK61_COLOUR_RED,
    RK61_COLOUR_BLUE,
    RK61_COLOUR_YELLOW,
    RK61_COLOUR_CYAN,
    RK61_COLOUR_MAGENTA,
    RK61_COLOUR_ORANGE,
    RK61_COLOUR_VIOLET,
    RK61_COLOUR_COUNT,
};

#define RK61_COLOUR_NORMAL 255u
// Cap every channel at the baseline's tested 64-count short pulse.
#define RK61_LED_MAX_PULSE       64u
#define RK61_LED_BRIGHTNESS_STEP 16u

// Called by the LED ISR: return NORMAL to use the user's selected base colour.
uint8_t rk61_led_override_colour(void);
