#include "kbdef.h"
#include "radio.h"
#include "usb.h"
#include "report.h"
#include "host.h"
#include "debug.h"

// Automatic mode initially follows stock's apparent USB-detect pin P5.6.
// Fn+R / Fn+T select dongle / USB; Fn+B/N/M select Bluetooth slots.
// Explicit selection overrides the automatic route until the next power cycle.
static bool                      radio_mode;
static bool                      manual_mode;
static uint8_t                   radio_link; // 0=dongle, 1..3=Bluetooth
static uint16_t                  mode_debounce;
static __xdata report_keyboard_t blank_keyboard;
static __xdata report_nkro_t     blank_nkro;

static void set_mode(bool wireless, uint8_t link)
{
    if (link > 3 || (radio_mode == wireless && (!wireless || radio_link == link))) {
        return;
    }
    // Stop media/system holds on the old route before selecting a new host.
    host_consumer_send(0);
    host_system_send(0);
    if (radio_mode) {
        rk61_radio_release();
    } else {
        blank_nkro.report_id = REPORT_ID_NKRO;
        usb_send_report(&blank_keyboard);
        usb_send_nkro(&blank_nkro);
    }
    radio_mode = wireless;
    radio_link = wireless ? link : 0;
    if (wireless) {
        rk61_radio_select_link(link, false);
    } else {
        rk61_radio_select(false);
    }
}

void kb_init(void)
{
    rk61_radio_init();
    radio_mode    = false;
    manual_mode   = false;
    radio_link    = 0;
    mode_debounce = 0;
    if (!P5_6) {
        set_mode(true, 0);
    }
}

void kb_update_switches(void)
{
    if (manual_mode || radio_mode == !P5_6) {
        mode_debounce = 0;
    } else if (++mode_debounce == 256) {
        mode_debounce = 0;
        set_mode(!P5_6, 0);
    }
}

bool kb_process_record(uint16_t keycode, bool pressed)
{
    switch (keycode) {
        case RK61_RF_24G:
        case RK61_USB_MODE:
            if (pressed) {
                manual_mode = true;
                set_mode(keycode == RK61_RF_24G, 0);
            }
            return false;
        case RK61_BT1:
        case RK61_BT2:
        case RK61_BT3:
            if (pressed) {
                manual_mode = true;
                set_mode(true, (uint8_t)(keycode - RK61_BT1 + 1));
            }
            return false;
        case RK61_BT_PAIR:
            if (pressed && radio_mode && radio_link >= 1 && radio_link <= 3) {
                host_consumer_send(0);
                host_system_send(0);
                rk61_radio_release();
                rk61_radio_select_link(radio_link, true);
            }
            return false;
        case RK61_RF_STATUS:
            if (pressed) {
                rk61_radio_status();
            }
            return false;
        default:
            return true; // LED keys are handled by layout_process_record
    }
}

void kb_update(void)
{
    if (radio_mode) {
        rk61_radio_task();
    }
}

void kb_send_report(__xdata report_keyboard_t *report)
{
    if (radio_mode) {
        rk61_radio_keyboard(report);
    } else {
        usb_send_report(report);
    }
}

void kb_send_nkro(__xdata report_nkro_t *report)
{
    if (radio_mode) {
        rk61_radio_nkro(report);
    } else {
        usb_send_nkro(report);
    }
}

void kb_send_extra(__xdata report_extra_t *report)
{
    if (radio_mode) {
        rk61_radio_extra(report);
    } else {
        usb_send_extra(report);
    }
}
