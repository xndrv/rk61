#include "kbdef.h"
#include "indicators.h"
#include "pwm.h"
#include "user_layout.h"
#include "user_matrix.h"

// Stock routine 0x6E6F uses period 0x0537 and these staggered DUTY1 values.
// Stock 0x9885 blanks every channel by setting DUTY2 equal to DUTY1.
// Test a short pulse only; the physical A/B/C colour order is not yet verified.
#define LED_TEST_PULSE 64u
#define LED_PARKED     (PWM_MOD | PWM_CLK_DIV_4)

// PWM channel, stock off point, colour group, populated ANSI LED row.
// Group 3 means all groups. The original extra row (PWM20..22) stays off.
#define LED_ACTIVE_CHANNELS(X) \
    X(PWM00, 0x35u, 0, 1)      \
    X(PWM01, 0x36u, 1, 1)      \
    X(PWM02, 0x37u, 2, 1)      \
    X(PWM03, 0x32u, 0, 1)      \
    X(PWM04, 0x33u, 1, 1)      \
    X(PWM05, 0x34u, 2, 1)      \
    X(PWM10, 0x2Cu, 0, 1)      \
    X(PWM11, 0x2Du, 1, 1)      \
    X(PWM12, 0x2Eu, 2, 1)      \
    X(PWM13, 0x2Fu, 0, 1)      \
    X(PWM14, 0x30u, 1, 1)      \
    X(PWM15, 0x31u, 2, 1)      \
    X(PWM23, 0x29u, 0, 1)      \
    X(PWM24, 0x2Au, 1, 1)      \
    X(PWM25, 0x2Bu, 2, 1)

#define LED_CHANNELS(X)    \
    LED_ACTIVE_CHANNELS(X) \
    X(PWM20, 0x26u, 0, 0)  \
    X(PWM21, 0x27u, 1, 0)  \
    X(PWM22, 0x28u, 2, 0)

static volatile uint8_t led_enabled;
static volatile uint8_t led_group;
static uint8_t          led_col;

void indicators_pwm_disable(void)
{
#define PARK(channel, off, group, populated) channel##CON = LED_PARKED;
    LED_CHANNELS(PARK)
#undef PARK
    user_matrix_cols_deselect_all();
}

// matrix_scan_full calls this after scanning. Leave everything blank until the
// next LED slot selects exactly one column; do not restore the previous sink.
void indicators_pwm_enable(void) {}

void indicators_init(void)
{
    led_enabled = 0;
    led_group   = 3;
    led_col     = 0;
    indicators_pwm_disable();

    // These PWM-source pins are outputs with low idle latches in stock 0xA829.
    P1 &= (uint8_t)~0x38u;
    P2 &= (uint8_t)~0x3Fu;
    P3 &= (uint8_t)~0x3Fu;
    P1PCR &= (uint8_t)~0x38u;
    P2PCR &= (uint8_t)~0x3Fu;
    P3PCR &= (uint8_t)~0x3Fu;
    DRVCON = DRVCON_UNLOCK_P1;
    P1DRV  = GPIO_DRIVE_25MA;
    DRVCON = DRVCON_UNLOCK_P2;
    P2DRV  = GPIO_DRIVE_25MA;
    DRVCON = DRVCON_UNLOCK_P3;
    P3DRV  = GPIO_DRIVE_25MA;
    DRVCON = DRVCON_LOCK;
    P1CR |= 0x38u;
    P2CR |= 0x3Fu;
    P3CR |= 0x3Fu;

    PWM0PERDH = PWM1PERDH = PWM2PERDH = 0x05;
    PWM0PERDL = PWM1PERDL = PWM2PERDL = 0x37;
#define INIT(channel, off, group, populated) SET_PWM_DUTY(channel, off, off);
    LED_CHANNELS(INIT)
#undef INIT
}

void indicators_start(void)
{
    led_enabled = 1;
}

bool indicators_update_step(keyboard_state_t *keyboard, uint8_t current_step)
{
    keyboard;
    current_step;
    indicators_pwm_disable();
    const uint8_t selected_group = led_group;
    if (led_enabled) {
#define PAINT(channel, off, group, populated) SET_PWM_DUTY_2(channel, (uint16_t)((off) + ((selected_group == 3 || selected_group == (group)) ? LED_TEST_PULSE : 0u)));
        LED_ACTIVE_CHANNELS(PAINT)
#undef PAINT
        user_matrix_col_select(led_col);
        // Stock bank control: no PWM IRQ; SMK's timer schedules the slots.
#define ARM(channel, off, group, populated) channel##CON = PWM_SS;
        LED_CHANNELS(ARM)
#undef ARM
        PWM00CON = (uint8_t)(PWM_MODE_ENABLE | PWM_SS | PWM_CLK_DIV_4);
        PWM10CON = (uint8_t)(PWM_MODE_ENABLE | PWM_SS | PWM_CLK_DIV_4);
        PWM20CON = (uint8_t)(PWM_MODE_ENABLE | PWM_SS | PWM_CLK_DIV_4);
    }
    if (++led_col == MATRIX_COLS) {
        led_col = 0;
        return true;
    }
    return false;
}

bool layout_process_record(uint16_t keycode, bool pressed)
{
    switch (keycode) {
        case RK61_LED_TOGGLE:
            if (pressed) {
                led_enabled ^= 1;
            }
            return false;
        case RK61_LED_CHANNEL:
            if (pressed) {
                led_group = (uint8_t)((led_group + 1) & 3u);
            }
            return false;
        default:
            return true;
    }
}
