#pragma once

#include "sh68f90.h"
#include "keycodes.h"

#define MATRIX_ROWS 5
#define MATRIX_COLS 14
