#include "kbdef.h"
#include "radio.h"
#include "usb.h"
#include "report.h"
#include "debug.h"

// Automatic mode initially follows stock's apparent USB-detect pin P5.6.
// Fn+R / Fn+T override it explicitly for the first hardware test.
static bool                      radio_mode;
static bool                      manual_mode;
static uint16_t                  mode_debounce;
static __xdata report_keyboard_t blank_keyboard;
static __xdata report_nkro_t     blank_nkro;

static void set_mode(bool wireless)
{
    if (radio_mode == wireless) {
        return;
    }
    if (radio_mode) {
        rk61_radio_release();
    } else {
        blank_nkro.report_id = REPORT_ID_NKRO;
        usb_send_report(&blank_keyboard);
        usb_send_nkro(&blank_nkro);
    }
    radio_mode = wireless;
    rk61_radio_select(wireless);
}

void kb_init(void)
{
    rk61_radio_init();
    radio_mode    = false;
    manual_mode   = false;
    mode_debounce = 0;
    if (!P5_6) {
        set_mode(true);
    }
}

void kb_update_switches(void)
{
    if (manual_mode || radio_mode == !P5_6) {
        mode_debounce = 0;
    } else if (++mode_debounce == 256) {
        mode_debounce = 0;
        set_mode(!P5_6);
    }
}

bool kb_process_record(uint16_t keycode, bool pressed)
{
    switch (keycode) {
        case RK61_RF_24G:
        case RK61_USB_MODE:
            if (pressed) {
                manual_mode = true;
                set_mode(keycode == RK61_RF_24G);
            }
            return false;
        case RK61_RF_STATUS:
            if (pressed) {
                rk61_radio_status();
            }
            return false;
        default:
            return true; // LED keys are handled by layout_process_record
    }
}

void kb_update(void)
{
    if (radio_mode) {
        rk61_radio_task();
    }
}

void kb_send_report(__xdata report_keyboard_t *report)
{
    if (radio_mode) {
        rk61_radio_keyboard(report);
    } else {
        usb_send_report(report);
    }
}

void kb_send_nkro(__xdata report_nkro_t *report)
{
    if (radio_mode) {
        rk61_radio_nkro(report);
    } else {
        usb_send_nkro(report);
    }
}

void kb_send_extra(__xdata report_extra_t *report)
{
    if (radio_mode) {
        rk61_radio_extra(report);
    } else {
        usb_send_extra(report);
    }
}
