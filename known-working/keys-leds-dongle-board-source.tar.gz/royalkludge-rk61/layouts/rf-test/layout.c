#include "kbdef.h"
#include "layout.h"

// LED diagnostics: Fn+Q toggles; Fn+E cycles all / channel A / B / C.
// Column order is electrical (from the stock dump), not a rectangular drawing.
// clang-format off
const uint16_t keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
    [0] = {
        {KC_ESC,  KC_1,    KC_2,    KC_3,  KC_4, KC_5,   KC_6, KC_7, KC_8,    KC_9,   KC_0,    KC_MINS, KC_EQL, KC_BSPC},
        {KC_TAB,  KC_Q,    KC_W,    KC_E,  KC_R, KC_T,   KC_Y, KC_U, KC_I,    KC_O,   KC_P,    KC_LBRC, KC_RBRC, KC_BSLS},
        {KC_CAPS, KC_A,    KC_S,    KC_D,  KC_F, KC_G,   KC_H, KC_J, KC_K,    KC_L,   KC_SCLN, KC_QUOT, KC_NO, KC_ENT},
        {KC_LSFT, KC_Z,    KC_X,    KC_C,  KC_V, KC_B,   KC_N, KC_M, KC_COMM, KC_DOT, KC_SLSH, KC_NO, KC_NO, KC_RSFT},
        {KC_LCTL, KC_LGUI, KC_LALT, KC_NO, KC_NO, KC_SPC, KC_NO, KC_NO, KC_RALT, KC_APP, KC_RCTL, KC_NO, KC_NO, MO(1)},
    },
    [1] = {
        {KC_GRV, KC_F1, KC_F2, KC_F3, KC_F4, KC_F5, KC_F6, KC_F7, KC_F8, KC_F9, KC_F10, KC_F11, KC_F12, KC_DEL},
        {KC_TRNS, RK61_LED_TOGGLE, KC_UP, RK61_LED_CHANNEL, RK61_RF_24G, RK61_USB_MODE, RK61_RF_STATUS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS},
        {KC_TRNS, KC_LEFT, KC_DOWN, KC_RGHT, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_NO, KC_TRNS},
        {KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_NO, KC_NO, KC_TRNS},
        {KC_TRNS, KC_TRNS, KC_TRNS, KC_NO, KC_NO, KC_TRNS, KC_NO, KC_NO, KC_TRNS, KC_TRNS, KC_TRNS, KC_NO, KC_NO, KC_TRNS},
    },
};
// clang-format on
