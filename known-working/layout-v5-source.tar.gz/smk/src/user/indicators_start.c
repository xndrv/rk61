void indicators_start() {}
