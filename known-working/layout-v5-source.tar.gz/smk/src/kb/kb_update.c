void kb_update() {}
