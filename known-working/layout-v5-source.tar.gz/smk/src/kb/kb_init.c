void kb_init() {}
